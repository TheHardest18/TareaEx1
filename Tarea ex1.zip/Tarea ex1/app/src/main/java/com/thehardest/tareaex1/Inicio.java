package com.thehardest.tareaex1;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Inicio extends AppCompatActivity {

    private Button  btnIniciar;
    private ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);

        btnIniciar = findViewById(R.id.btnInicio);
        progressDialog = new ProgressDialog(this);

        btnIniciar.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                progressDialog.setMessage("Espere un momento pronto se estara quemando!!!!");
                progressDialog.show();

                Intent intent = new Intent(Inicio.this, MainActivity.class);
                startActivity(intent);


            }
        });
        progressDialog.dismiss();

}
}