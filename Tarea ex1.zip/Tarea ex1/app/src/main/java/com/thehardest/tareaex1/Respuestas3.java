package com.thehardest.tareaex1;

public class Respuestas3 {
    public Respuestas3(int idRespuesta3) {
        IdRespuesta3 = idRespuesta3;
    }

    private int IdRespuesta3;
//

    public void setIdRespuesta3(int idRespuesta3) {
        IdRespuesta3 = idRespuesta3;
    }


    public int getTextRespuesta3(){return IdRespuesta3;}

}


