package com.thehardest.tareaex1;

public class Respuestas4 {
    public Respuestas4(int idRespuesta4) {
        IdRespuesta4 = idRespuesta4;
    }

    private int IdRespuesta4;
//
public void setIdRespuesta4(int idRespuesta4) {
        IdRespuesta4 = idRespuesta4;
    }
//
public int getTextRespuesta4() {
        return IdRespuesta4;
    }

}
