package com.thehardest.tareaex1;

import android.widget.RadioButton;

public class Respuestas {

    private int IdRespuesta1;


    public Respuestas(int idRespuesta1){

        IdRespuesta1 = idRespuesta1;

    }

    public void setIdRespuesta1(int idRespuesta1) {
        IdRespuesta1 = idRespuesta1;
    }

    public int getTextRespuesta1() {
        return IdRespuesta1;
    }



}
