package com.thehardest.tareaex1;

public class Respuestas5 {
    private int IdRespuesta5;

    public Respuestas5(int idRespuesta5) {
        IdRespuesta5 = idRespuesta5;
    }

    public void setIdRespuesta5(int idRespuesta5) {
        IdRespuesta5 = idRespuesta5;
}
    public int getTextRespuesta5() {
        return IdRespuesta5;
    }
}