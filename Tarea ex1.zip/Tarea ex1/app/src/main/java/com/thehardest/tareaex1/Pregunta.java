package com.thehardest.tareaex1;

import android.widget.RadioButton;

public class Pregunta {
    private int IdPregunta;

    public Pregunta(int pregunta1, RadioButton rbtn2) {
    }
    public int getTextPregunta() {
        return IdPregunta;
    }

    public void setIdPregunta(int idPregunta) {
        IdPregunta = idPregunta;
    }

    public Pregunta(int idPregunta) {
        IdPregunta = idPregunta;

    }

}
