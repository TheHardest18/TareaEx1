package com.thehardest.tareaex1;

public class Respuestas2{


    public Respuestas2(int idRespuesta2) {
        IdRespuesta2 = idRespuesta2;
    }

    private int IdRespuesta2;


    public void setIdRespuesta2(int idRespuesta2) {
        IdRespuesta2 = idRespuesta2;
    }


    public int getTextRespuesta2() {
        return IdRespuesta2;
    }

}
