package com.thehardest.tareaex1;

import androidx.annotation.CheckResult;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CheckedTextView;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RadioButton rbtn1;
    private RadioButton rbtn2;
    private RadioButton rbtn3;
    private RadioButton rbtn4;
    private RadioButton rbtn5;
    private RadioGroup grupo;
    //private RadioButton rNinguna;
    private ImageButton imSiguiente;
    private ImageButton imAnterior;
    private TextView txtPregunta;
    private ArrayList<Integer> mAnsweredQuestions = new ArrayList<>();
    private Pregunta[] mQuestionBank = new Pregunta[]{
            new Pregunta(R.string.Pregunta1),
            new Pregunta(R.string.Pregunta2),
            new Pregunta(R.string.Pregunta3),
            new Pregunta(R.string.Pregunta4),
            new Pregunta(R.string.Pregunta5),

    };
    private Respuestas[] mRespuestasBank = new Respuestas[]{
            new Respuestas(R.string.Respuesta1),

    };
    private Respuestas2[] mRespuestasBank2 = new Respuestas2[]{
            new Respuestas2(R.string.Respuesta2),
    };
    private Respuestas3[] mRespuestasBank3 = new Respuestas3[]{

            new Respuestas3(R.string.Respuesta3),
    };
    private Respuestas4[] mRespuestasBank4 = new Respuestas4[]{

            new Respuestas4(R.string.Respuesta4),
    };
    private Respuestas5[] mRespuestasBank5 = new Respuestas5[]{
              new Respuestas5(R.string.Respuesta5),
    };


    private int mCurrentIndex = 0;
    private int mCurrentIndex2 = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        grupo = (RadioGroup) findViewById(R.id.rdgGroup);
        txtPregunta = (TextView) findViewById(R.id.txtPregunta);
        //Validaciones
        rbtn1 = (RadioButton) findViewById(R.id.rdbtn1);
        rbtn3 = (RadioButton) findViewById(R.id.rdbtn3);
        rbtn4 = (RadioButton) findViewById(R.id.rdbtn4);
        rbtn5 = (RadioButton) findViewById(R.id.rdbtn5);

        rbtn1.setOnClickListener(view -> {
            if (mCurrentIndex == 0 && rbtn1.isChecked()) {
                Toast.makeText(this, "¡Respuesta Correcta!", Toast.LENGTH_LONG).show();
            } else {

                Toast.makeText(this, "Respuesta incorrecta", Toast.LENGTH_LONG).show();
            }
        });

        rbtn2 = (RadioButton) findViewById(R.id.rdbtn2);
        rbtn2.setOnClickListener(view -> {
            if (mCurrentIndex == 1 && rbtn2.isChecked()) {
                Toast.makeText(this, "¡Respuesta Correcta!", Toast.LENGTH_LONG).show();
            } else {

                Toast.makeText(this, "Respuesta incorrecta", Toast.LENGTH_LONG).show();
            }
        });




        rbtn3.setOnClickListener(view -> {
            if (mCurrentIndex == 2 && rbtn3.isChecked()) {
                Toast.makeText(this, "¡Respuesta Correcta!", Toast.LENGTH_LONG).show();
            } else {

                Toast.makeText(this, "Respuesta incorrecta", Toast.LENGTH_LONG).show();
            }
        });


        rbtn4.setOnClickListener(view -> {
        if (mCurrentIndex == 3 && rbtn4.isChecked()) {
            Toast.makeText(this, "¡Respuesta Correcta!", Toast.LENGTH_LONG).show();
        } else {

            Toast.makeText(this, "Respuesta incorrecta", Toast.LENGTH_LONG).show();
        }
    });

        rbtn5.setOnClickListener(view -> {
                if (mCurrentIndex == 4 && rbtn5.isChecked()) {
                Toast.makeText(this, "¡Respuesta Correcta!", Toast.LENGTH_LONG).show();
                } else {

                Toast.makeText(this, "Respuesta incorrecta", Toast.LENGTH_LONG).show();
                }
                });

        imSiguiente = (ImageButton) findViewById(R.id.imgSiguiente);
        imSiguiente.setOnClickListener(view -> {
            mCurrentIndex = (mCurrentIndex + 1) % mQuestionBank.length;
            mCurrentIndex2 = (mCurrentIndex2 + 1) % mRespuestasBank.length;
            mCurrentIndex2 = (mCurrentIndex2 + 1) % mRespuestasBank2.length;
            mCurrentIndex2 = (mCurrentIndex2 + 1) % mRespuestasBank3.length;
            mCurrentIndex2 = (mCurrentIndex2 + 1) % mRespuestasBank4.length;
            mCurrentIndex2 = (mCurrentIndex2 + 1) % mRespuestasBank5.length;
            //mCurrentIndex2 = (mCurrentIndex + 1) % mRespuestasBank.length;
            ActualizarPregunta();
            ActualizarRespuesta();

        });
        imAnterior = (ImageButton) findViewById(R.id.imgAnterior);
        imAnterior.setOnClickListener(view -> {
            if (mCurrentIndex > 0) {
                mCurrentIndex = (mCurrentIndex - 1) % mQuestionBank.length;
                mCurrentIndex2 = (mCurrentIndex2 - 1) % mRespuestasBank.length;
                mCurrentIndex2 = (mCurrentIndex2 - 1) % mRespuestasBank2.length;
                mCurrentIndex2 = (mCurrentIndex2 - 1) % mRespuestasBank3.length;
                mCurrentIndex2 = (mCurrentIndex2 - 1) % mRespuestasBank4.length;
                mCurrentIndex2 = (mCurrentIndex2 - 1) % mRespuestasBank5.length;
              //  mCurrentIndex2 = (mCurrentIndex - 1) % mRespuestasBank.length;
            } else {
                mCurrentIndex = mQuestionBank.length - 1;
                mCurrentIndex2 = mRespuestasBank.length - 1;
                mCurrentIndex2 = mRespuestasBank2.length - 1;
                mCurrentIndex2 = mRespuestasBank3.length - 1;
                mCurrentIndex2 = mRespuestasBank4.length - 1;
                mCurrentIndex2 = mRespuestasBank5.length - 1;
                //mCurrentIndex2 = mRespuestasBank.length - 1;
            }
            ActualizarPregunta();
            ActualizarRespuesta();

        });
        ActualizarPregunta();
        ActualizarRespuesta();

    }



    private void ActualizarPregunta() {
        int Pregunta1 = mQuestionBank[mCurrentIndex].getTextPregunta();

        txtPregunta.setText(Pregunta1);
        if (rbtn1.isChecked() || rbtn2.isChecked() || rbtn3.isChecked() || rbtn4.isChecked() || rbtn5.isChecked()) {
            grupo.clearCheck();
        }

    }
    private void ActualizarRespuesta () {
        int Respuesta = mRespuestasBank[mCurrentIndex2].getTextRespuesta1();
        int Respuesta2 = mRespuestasBank2[mCurrentIndex2].getTextRespuesta2();
        int Respuesta3 = mRespuestasBank3[mCurrentIndex2].getTextRespuesta3();
        int Respuesta4 = mRespuestasBank4[mCurrentIndex2].getTextRespuesta4();
        int Respuesta5 = mRespuestasBank5[mCurrentIndex2].getTextRespuesta5();

           rbtn1.setText(Respuesta);
           rbtn2.setText(Respuesta2);
           rbtn3.setText(Respuesta3);
           rbtn4.setText(Respuesta4);
           rbtn5.setText(Respuesta5);




    }
}
